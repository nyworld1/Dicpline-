# Ash Discipline

A polished personal discipline app based on the original 111 Discipline UI.

## What changed
- UI/UX preserved and enhanced rather than replaced.
- App name: **Ash Discipline**.
- No login screen.
- Works locally/offline with localStorage.
- Add, edit, delete your own habits.
- Every habit can have a name, reminder time, and start date.
- Your 111-day journey remains available.
- Profile name and challenge start date.
- Firebase Realtime Database cloud sync across devices using a **sync code** instead of login.
- JSON backup/export.
- Dark/light mode and existing focus timer retained.

## Firebase setup (one time)
1. Create a Firebase project.
2. Add a Web App in Firebase Project Settings.
3. Copy the Web App configuration into `FIREBASE_CONFIG` near the top of `index.html`.
4. Create **Realtime Database**.
5. For a no-login personal build, the database must allow the web app to read/write the sync path. A simple development rule is:
```json
{
  "rules": {
    "ash-discipline": {
      ".read": true,
      ".write": true
    }
  }
}
```
This means the sync code is the access key. Do not share it. For stronger privacy, Firebase Authentication should be used instead of no-login sync.

6. Open/host the app. On the first device, copy the generated sync code from Profile → Cloud sync. Enter the same code on another device and press Sync.

## Important
Because you requested **no login**, Firebase cannot know that two devices belong to the same person. The sync code is therefore used as the shared identifier. Anyone who knows the code can read/write that synced data.

The UI is a static HTML/CSS/JS app and can be hosted on GitHub Pages or another HTTPS static host.
